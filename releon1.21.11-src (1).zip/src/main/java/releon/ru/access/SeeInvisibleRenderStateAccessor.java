package releon.ru.access;

public interface SeeInvisibleRenderStateAccessor {
   void releon$setSeeInvisibleAlpha(float var1);

   float releon$getSeeInvisibleAlpha();

   boolean releon$shouldRenderSeeInvisible();

   void releon$setChamsColor(int var1);

   int releon$getChamsColor();

   boolean releon$shouldRenderChams();
}
