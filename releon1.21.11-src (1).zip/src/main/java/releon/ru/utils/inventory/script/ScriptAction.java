package releon.ru.utils.inventory.script;

@FunctionalInterface
public interface ScriptAction {
   void perform();
}
