package releon.ru.api.events.impl;

import releon.ru.api.events.Event;

public final class TextFactoryEvent implements Event {
   private String text;

   public TextFactoryEvent(String text) {
      this.text = text == null ? "" : text;
   }

   public String getText() {
      return this.text;
   }

   public void setText(String text) {
      this.text = text == null ? "" : text;
   }

   public void replaceText(String target, String replacement) {
      if (target != null && !target.isEmpty() && replacement != null) {
         this.text = this.text.replace(target, replacement);
      }
   }
}
