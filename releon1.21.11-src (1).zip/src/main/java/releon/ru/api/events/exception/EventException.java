package releon.ru.api.events.exception;

public class EventException extends RuntimeException {
   public EventException(String message) {
      super(message);
   }

   public EventException(String message, Throwable cause) {
      super(message, cause);
   }
}
