package releon.ru.api.settings;

public enum SettingType {
   BOOLEAN,
   NUMBER,
   MODE,
   MULTI_MODE,
   STRING,
   COLOR,
   BIND,
   BUTTON;

   private SettingType() {
   }
}
