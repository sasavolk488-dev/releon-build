package releon.ru;

import net.minecraft.client.MinecraftClient;

public interface IMinecraft {
   MinecraftClient mc = MinecraftClient.getInstance();
}
