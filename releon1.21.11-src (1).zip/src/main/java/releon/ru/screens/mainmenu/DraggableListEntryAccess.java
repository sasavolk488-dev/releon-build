package releon.ru.screens.mainmenu;

public interface DraggableListEntryAccess {
   boolean releon$isDragging();

   float releon$getDragOffsetX();

   float releon$getDragOffsetY();
}
