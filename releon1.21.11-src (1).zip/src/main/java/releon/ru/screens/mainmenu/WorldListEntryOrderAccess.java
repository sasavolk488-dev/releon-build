package releon.ru.screens.mainmenu;

public interface WorldListEntryOrderAccess {
   String releon$getLevelId();
}
